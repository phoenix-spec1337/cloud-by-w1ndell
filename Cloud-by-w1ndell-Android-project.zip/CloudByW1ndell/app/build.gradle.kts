plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.w1ndell.cloud"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.w1ndell.cloud"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
